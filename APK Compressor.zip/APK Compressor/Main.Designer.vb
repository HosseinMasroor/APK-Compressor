﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.List = New System.Windows.Forms.DataGridView()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.FolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.ListEmpty = New System.Windows.Forms.Label()
        Me.PleaseWait = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.BackgroundWorker = New System.ComponentModel.BackgroundWorker()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Start = New System.Windows.Forms.Button()
        Me.Add = New System.Windows.Forms.Button()
        Me.Language = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.About = New System.Windows.Forms.Button()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.FileName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CompressedSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.List, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'List
        '
        Me.List.AllowDrop = True
        Me.List.AllowUserToAddRows = False
        Me.List.AllowUserToDeleteRows = False
        Me.List.AllowUserToResizeRows = False
        Me.List.BackgroundColor = System.Drawing.SystemColors.Window
        Me.List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.List.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FileName, Me.FileSize, Me.CompressedSize})
        Me.List.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.List.Location = New System.Drawing.Point(12, 72)
        Me.List.Name = "List"
        Me.List.RowHeadersVisible = False
        Me.List.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.List.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.List.Size = New System.Drawing.Size(320, 253)
        Me.List.TabIndex = 1
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.Filter = "Android & Java Applications|*.apk;*.jar"
        Me.OpenFileDialog.Multiselect = True
        Me.OpenFileDialog.Title = "Choose Android (.apk) or Java (.jar) Applications:"
        '
        'ListEmpty
        '
        Me.ListEmpty.BackColor = System.Drawing.SystemColors.Window
        Me.ListEmpty.Enabled = False
        Me.ListEmpty.Location = New System.Drawing.Point(13, 106)
        Me.ListEmpty.Name = "ListEmpty"
        Me.ListEmpty.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ListEmpty.Size = New System.Drawing.Size(318, 218)
        Me.ListEmpty.TabIndex = 3
        Me.ListEmpty.Text = "Drag and drop your .apk or .jar file(s) here or click the top button"
        Me.ListEmpty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PleaseWait
        '
        Me.PleaseWait.Location = New System.Drawing.Point(13, 328)
        Me.PleaseWait.Name = "PleaseWait"
        Me.PleaseWait.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PleaseWait.Size = New System.Drawing.Size(319, 25)
        Me.PleaseWait.TabIndex = 4
        Me.PleaseWait.Text = "...Please wait"
        Me.PleaseWait.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.PleaseWait.Visible = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 353)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(320, 23)
        Me.ProgressBar1.TabIndex = 5
        Me.ProgressBar1.Visible = False
        '
        'BackgroundWorker
        '
        '
        'Timer
        '
        Me.Timer.Interval = 1
        '
        'Start
        '
        Me.Start.AutoSize = True
        Me.Start.BackgroundImage = Global.APK_Compressor.My.Resources.Resources.APK
        Me.Start.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Start.Image = Global.APK_Compressor.My.Resources.Resources.APK
        Me.Start.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Start.Location = New System.Drawing.Point(12, 331)
        Me.Start.Name = "Start"
        Me.Start.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Start.Size = New System.Drawing.Size(320, 54)
        Me.Start.TabIndex = 2
        Me.Start.Text = "شروع فشرده سازی"
        Me.Start.UseVisualStyleBackColor = True
        '
        'Add
        '
        Me.Add.AutoSize = True
        Me.Add.BackgroundImage = Global.APK_Compressor.My.Resources.Resources.APK
        Me.Add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Add.Image = Global.APK_Compressor.My.Resources.Resources.APK
        Me.Add.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Add.Location = New System.Drawing.Point(12, 12)
        Me.Add.Name = "Add"
        Me.Add.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Add.Size = New System.Drawing.Size(320, 54)
        Me.Add.TabIndex = 0
        Me.Add.Text = "Add file(s) to list"
        Me.Add.UseVisualStyleBackColor = True
        '
        'Language
        '
        Me.Language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Language.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Language.FormattingEnabled = True
        Me.Language.Items.AddRange(New Object() {"English", "Persian"})
        Me.Language.Location = New System.Drawing.Point(12, 404)
        Me.Language.Name = "Language"
        Me.Language.Size = New System.Drawing.Size(115, 21)
        Me.Language.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 388)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Language:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.Label2.Location = New System.Drawing.Point(238, 424)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "By Hossein Masroor"
        '
        'About
        '
        Me.About.AutoSize = True
        Me.About.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.About.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.About.ForeColor = System.Drawing.Color.Blue
        Me.About.Location = New System.Drawing.Point(240, 388)
        Me.About.Name = "About"
        Me.About.Size = New System.Drawing.Size(93, 33)
        Me.About.TabIndex = 6
        Me.About.Text = "Github"
        Me.About.UseVisualStyleBackColor = True
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(12, 375)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(320, 10)
        Me.ProgressBar2.TabIndex = 10
        Me.ProgressBar2.Visible = False
        '
        'FileName
        '
        Me.FileName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.FileName.HeaderText = "File Name"
        Me.FileName.Name = "FileName"
        Me.FileName.ReadOnly = True
        '
        'FileSize
        '
        Me.FileSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.FileSize.HeaderText = "Before"
        Me.FileSize.Name = "FileSize"
        Me.FileSize.ReadOnly = True
        Me.FileSize.Width = 98
        '
        'CompressedSize
        '
        Me.CompressedSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader
        Me.CompressedSize.HeaderText = "After"
        Me.CompressedSize.Name = "CompressedSize"
        Me.CompressedSize.ReadOnly = True
        Me.CompressedSize.Width = 83
        '
        'Main
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(344, 442)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Language)
        Me.Controls.Add(Me.About)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.PleaseWait)
        Me.Controls.Add(Me.ListEmpty)
        Me.Controls.Add(Me.Start)
        Me.Controls.Add(Me.List)
        Me.Controls.Add(Me.Add)
        Me.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "APK Compressor 1.0"
        CType(Me.List, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Add As System.Windows.Forms.Button
    Friend WithEvents List As System.Windows.Forms.DataGridView
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Start As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ListEmpty As System.Windows.Forms.Label
    Friend WithEvents PleaseWait As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents BackgroundWorker As System.ComponentModel.BackgroundWorker
    Friend WithEvents Timer As System.Windows.Forms.Timer
    Friend WithEvents Language As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents About As System.Windows.Forms.Button
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents FileName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FileSize As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CompressedSize As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
