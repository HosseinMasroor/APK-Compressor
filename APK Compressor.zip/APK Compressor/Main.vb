﻿Public Class Main
    Private Lang = "fa"
    Private Completed As Boolean = False
    Private Progress1 As Integer = 0
    Private Progress2 As Integer = 0
    Private Current As DataGridViewCell = Nothing
    Private Sub ChangeLanguage()
        If (Lang > "") Then
            Add.Text = My.Resources.ResourceManager.GetObject(Lang & "_add").ToString()
            Start.Text = My.Resources.ResourceManager.GetObject(Lang & "_start").ToString()
            ListEmpty.Text = My.Resources.ResourceManager.GetObject(Lang & "_listempty").ToString()
            PleaseWait.Text = My.Resources.ResourceManager.GetObject(Lang & "_wait").ToString()
            List.Columns.Item(0).HeaderText = My.Resources.ResourceManager.GetObject(Lang & "_filename").ToString()
            List.Columns.Item(1).HeaderText = My.Resources.ResourceManager.GetObject(Lang & "_before").ToString()
            List.Columns.Item(2).HeaderText = My.Resources.ResourceManager.GetObject(Lang & "_after").ToString()
            OpenFileDialog.Title = My.Resources.ResourceManager.GetObject(Lang & "_filebrowse").ToString()
        End If
    End Sub
    Private Function GetFileSize(ByVal FileName As String)
        Dim Size As Decimal = 0
        Dim SizeType As Short = 0
        Dim SizeTypes() As String = {"Bytes", "KB", "MB", "GB", "TB", "PT", "EX", "ZB", "YB"}
        If (IsNumeric(FileName)) Then
            Size = FileName
        Else
            Size = FileLen(FileName)
        End If
        While Size > 1024
            Size /= 1024
            SizeType += 1
        End While
        Dim SizeLen As Integer = Convert.ToInt32(Size).ToString().Length
        If (SizeLen < 3) Then
            If (SizeLen < 2) Then
                Return String.Format("{0:0.00} {1}", Size, SizeTypes(SizeType))
            Else
                Return String.Format("{0:0.0} {1}", Size, SizeTypes(SizeType))
            End If
        Else
            Return Math.Floor(Size).ToString() & " " & SizeTypes(SizeType)
        End If
    End Function
    Private Sub AddFile(ByVal File As String)
        If (Completed) Then
            Completed = False
            List.Rows.Clear()
        End If
        If (IO.File.Exists(File)) Then
            Dim CanAdd As Boolean = True
            For Each All As DataGridViewRow In List.Rows
                If (List.Item(0, All.Index).Tag.ToString.ToLower = File.ToLower) Then
                    CanAdd = False
                End If
            Next
            Dim Format As String = IO.Path.GetExtension(File).Replace(".", "").ToLower
            If (Format <> "apk" And Format <> "jar") Then
                CanAdd = False
            End If
            If (CanAdd) Then
                List.RowCount += 1
                List.Item(0, List.RowCount - 1).Value = IO.Path.GetFileName(File)
                List.Item(0, List.RowCount - 1).Tag = File
                List.Item(1, List.RowCount - 1).Value = GetFileSize(File)
            End If
        End If
    End Sub
    Private Sub Main_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        If (My.Application.CommandLineArgs.Count > 0) Then
            For Each File As String In My.Application.CommandLineArgs
                AddFile(File)
            Next
        End If
        Select Case System.Globalization.CultureInfo.CurrentCulture.TwoLetterISOLanguageName.ToLower()
            Case "fa"
                Language.SelectedIndex = 1
            Case "en"
                Language.SelectedIndex = 0
            Case Else
                Language.SelectedIndex = 0
        End Select
    End Sub
    Private Sub Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Add.Click
        If (OpenFileDialog.ShowDialog = DialogResult.OK) Then
            For Each File As String In OpenFileDialog.FileNames
                AddFile(File)
            Next
            If (BackgroundWorker.IsBusy) Then
                ProgressBar1.Maximum = List.Rows.Count * 2
            End If
        End If
    End Sub
    Private Sub List_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles List.Click
        If (List.RowCount = 0) Then
            Add.PerformClick()
        End If
    End Sub
    Private Sub List_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles List.PreviewKeyDown
        If (e.KeyCode = Keys.Delete And List.SelectedRows.Count > 0) Then
            For Each Item As DataGridViewRow In List.SelectedRows
                If (BackgroundWorker.IsBusy) Then
                    If (List.Item(0, Item.Index).Tag = Current.Tag) Then
                        MessageBox.Show(My.Resources.ResourceManager.GetObject(Lang & "_busy").ToString(), My.Resources.ResourceManager.GetObject(Lang & "_error").ToString(), MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Else
                        Item.Visible = False
                    End If
                Else
                    List.Rows.Remove(Item)
                End If
            Next
        End If
    End Sub
    Private Sub Start_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Start.Click
        If (List.RowCount > 0) Then
            If (FolderBrowserDialog.ShowDialog = DialogResult.OK) Then
                Start.Hide()
                PleaseWait.Show()
                ProgressBar1.Show()
                ProgressBar2.Show()
                Progress1 = 0
                Progress2 = 0
                Timer.Enabled = True
                ProgressBar1.Maximum = List.Rows.Count * 2
                BackgroundWorker.RunWorkerAsync()
            End If
        Else
            MessageBox.Show(My.Resources.ResourceManager.GetObject(Lang & "_nofile").ToString(), My.Resources.ResourceManager.GetObject(Lang & "_error").ToString(), MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    Private Sub List_RowsAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles List.RowsAdded
        ListEmpty.Hide()
    End Sub
    Private Sub List_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles List.RowsRemoved
        If (List.RowCount = 0) Then
            ListEmpty.Show()
        End If
    End Sub
    Private Sub List_DragEnter(ByVal sender As Object, ByVal e As DragEventArgs) Handles List.DragEnter
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub
    Private Sub List_DragDrop(ByVal sender As Object, ByVal e As DragEventArgs) Handles List.DragDrop
        If (e.Data.GetDataPresent(DataFormats.FileDrop)) Then
            Dim Files As String() = e.Data.GetData(DataFormats.FileDrop)
            For Each File As String In e.Data.GetData(DataFormats.FileDrop)
                If (IO.Path.GetExtension(File) = ".lnk") Then
                    Dim ScriptHost As Object = CreateObject("wscript.shell")
                    Dim Shortcut As Object = ScriptHost.CreateShortcut(File)
                    AddFile(Shortcut.TargetPath)
                Else
                    AddFile(File)
                End If
            Next
        End If
    End Sub
    Private Sub ReadZip_Progress(ByVal sender As Object, ByVal e As Ionic.Zip.ExtractProgressEventArgs)
        Progress2 = e.EntriesExtracted * 100 / e.EntriesTotal
    End Sub
    Private Sub SaveZip_Progress(ByVal sender As Object, ByVal e As Ionic.Zip.SaveProgressEventArgs)
        Progress2 = e.EntriesSaved * 100 / e.EntriesTotal
    End Sub
    Private Sub BackgroundWorker_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker.DoWork
        For Each Row As DataGridViewRow In List.Rows
            Try
                Current = List.Item(0, Row.Index)
                If (Current.Visible) Then
                    Dim TempFile As String = My.Computer.FileSystem.GetTempFileName
                    Dim TempFolder As String = My.Computer.FileSystem.SpecialDirectories.Temp & "\" & IO.Path.GetFileNameWithoutExtension(TempFile)
                    Dim TargetFile As String = FolderBrowserDialog.SelectedPath & "\" & IO.Path.GetFileName(Current.Tag)
                    My.Computer.FileSystem.CreateDirectory(TempFolder)
                    My.Computer.FileSystem.DeleteFile(TempFile)
                    Using ZipFile As ZipFile = ZipFile.Read(Current.Tag.ToString())
                        AddHandler ZipFile.ExtractProgress, AddressOf ReadZip_Progress
                        ZipFile.AlternateEncoding = System.Text.Encoding.UTF8
                        ZipFile.AlternateEncodingUsage = ZipOption.AsNecessary
                        ZipFile.ExtractAll(TempFolder, ExtractExistingFileAction.OverwriteSilently)
                    End Using
                    Progress1 += 1
                    If (IO.File.Exists(TargetFile)) Then
                        IO.File.Delete(TargetFile)
                    End If
                    Using ZipFile As ZipFile = New ZipFile(TargetFile, System.Text.Encoding.UTF8)
                        AddHandler ZipFile.SaveProgress, AddressOf SaveZip_Progress
                        ZipFile.CompressionMethod = CompressionMethod.Deflate
                        ZipFile.CompressionLevel = Ionic.Zlib.CompressionLevel.BestCompression
                        ZipFile.UseZip64WhenSaving = Zip64Option.AsNecessary
                        ZipFile.TempFileFolder = My.Computer.FileSystem.SpecialDirectories.Temp
                        ZipFile.AddDirectory(TempFolder)
                        ZipFile.Save()
                    End Using
                    Progress1 += 1
                    List.Item(2, Row.Index).Value = GetFileSize(TargetFile)
                    My.Computer.FileSystem.DeleteDirectory(TempFolder, FileIO.DeleteDirectoryOption.DeleteAllContents)
                Else
                    Progress1 += 2
                End If
            Catch ex As Exception

            End Try
        Next
    End Sub
    Private Sub BackgroundWorker_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker.RunWorkerCompleted
        ProgressBar1.Hide()
        ProgressBar2.Hide()
        PleaseWait.Hide()
        Start.Show()
        For Each All As DataGridViewRow In List.Rows
            If (List.Item(0, All.Index).Visible = False) Then
                List.Rows.Remove(All)
            End If
        Next
        Process.Start(FolderBrowserDialog.SelectedPath)
        Timer.Enabled = False
        Completed = True
    End Sub
    Private Sub Timer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer.Tick
        ProgressBar1.Value = Progress1
        If (Progress2 > 0 And Progress2 <= 100) Then
            ProgressBar2.Value = Progress2
        End If
        If (Current Is Nothing) Then
        Else
            If (Current.RowIndex > 9) Then
                If (List.FirstDisplayedScrollingRowIndex < Current.RowIndex - 7) Then
                    List.FirstDisplayedScrollingRowIndex = Current.RowIndex - 7
                End If
            End If
        End If
    End Sub
    Private Sub Language_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Language.SelectedIndexChanged
        Select Case Language.SelectedIndex
            Case 0
                Lang = "en"
            Case 1
                Lang = "fa"
            Case Else
                Lang = "en"
        End Select
        ChangeLanguage()
    End Sub
    Private Sub About_Click(ByVal sender As Object, ByVal e As EventArgs) Handles About.Click
        Process.Start("https://github.com/HosseinMasroor/APK-Compressor")
    End Sub
End Class
